/* ---Dinosaur.h-----------------------------------------------------------------
    Dinosaur class specification file – you may also define your Dinosaur member functions 
    here or separate them out in an implementation file like I did

    Written by:  Phillip Caruthers               Tennessee Technological University
    Written for: CSC 1310                        July 10, 2021
------------------------------------------------------------------------------*/

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <cctype>

using namespace std;

class Dinosaur {
    private:
    public:
        string DinoName;
        string DinoDesc;
        int LP, HP;
        // Constructor
		Dinosaur()
		{}
        //Accessor and Mutator Functions go here
        int Damage(int diceRoll)
        {
            diceRoll = 6;
            srand(time(0));
            cout << "Dice roll is: " << rand()%diceRoll << endl;
            HP *= diceRoll;
            return HP;
        }
        //Print dino func
        void PrintDino()
        {}

};  
//The following binary search function is to search for a dinosaur name
int binarySearch(int arr[], int p, int r, int num) {
   if (p <= r) {
      int mid = (p + r)/2;
      if (arr[mid] == num)
         return mid ;
      if (arr[mid] > num)
         return binarySearch(arr, p, mid-1, num);
      if (arr[mid] < num)
         return binarySearch(arr, mid+1, r, num);
   }
   return -1;
}

//The following swapping, display, merge, and mergesort functions are for the mergesort algorithm
void swapping(int &a, int &b) {     //swap the content of a and b
   int temp;
   temp = a;
   a = b;
   b = temp;
}
void display(int *array, int size) {
   for(int i = 0; i<size; i++)
      cout << array[i] << " ";
   cout << endl;
}
void merge(int *array, int l, int m, int r) {
   int i, j, k, nl, nr;
   //size of left and right sub-arrays
   nl = m - l + 1; nr = r - m;
   int larr[nl], rarr[nr];
   //fill left and right sub-arrays
   for(i = 0; i < nl; i++)
      larr[i] = array[l + i];
   for(j = 0; j < nr; j++)
      rarr[j] = array[m + 1 + j];
   i = 0; j = 0; k = l;
   //marge temp arrays to real array
   while(i < nl && j < nr) {
      if(larr[i] <= rarr[j]) {
         array[k] = larr[i];
         i++;
      }else{
         array[k] = rarr[j];
         j++;
      }
      k++;
   }
   while(i < nl) {       //extra element in left array
      array[k] = larr[i];
      i++; k++;
   }
   while(j < nr) {     //extra element in right array
      array[k] = rarr[j];
      j++; k++;
   }
}
void mergeSort(int *array, int l, int r) {
   int m;
   if(l < r) {
      int m = l + (r - l) / 2;
      // Sort first and second arrays
      mergeSort(array, l, m);
      mergeSort(array, m+1, r);
      merge(array, l, m, r);
   }
}
/*int arr1[] = {1, 2, 3, 4, 5};
        int n = sizeof(arr1)/ sizeof(arr1[0]);
        int num;
        cout << "Enter the number to search: \n";
        cin >> num;
        int index = binarySearch (arr1, 0, n - 1, num);
        if(index == -1){
           cout<< num <<" is not present in the array";
        }else{
           cout<< num <<" is present at index "<< index <<" in the array";
        }
        int e;
        cout << "Enter the number of elements: ";
        cin >> e;
        int arr2[e];     //create an array with given number of elements
        cout << "Enter elements:" << endl;
        for(int i = 0; i<e; i++) {
           cin >> arr2[i];
        }
        cout << "Array before Sorting: ";
        display(arr2, e);
        mergeSort(arr2, 0, e - 1);     //(n-1) for last index
        cout << "Array after Sorting: ";
        display(arr2, e);
        */