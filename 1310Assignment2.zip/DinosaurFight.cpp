/* ---DinosaurFight.cpp-----------------------------------------------------------------
    Contains the main function and any additional functions you created to make the 
    program run

    Written by:  Phillip Caruthers               Tennessee Technological University
    Written for: CSC 1310                        July 10, 2021
------------------------------------------------------------------------------*/

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <cctype>
#include <stdlib.h>

using namespace std;

void srand(unsigned int seed);

void banner1() {
    cout << "\n++++++++++++++++++++++++++++++++++++++++++++++++\n";
    cout << "            Super Dinosaur Fight Game!          \n";
    cout << "++++++++++++++++++++++++++++++++++++++++++++++++\n\n";
}

void banner2() {
    cout << "************************************************\n";
    cout << "\n 1)Brachiosaurus   2)Pteradactyl   3)T-rex    \n";
    cout << " 4)Triceratops     5)Velociraptor             \n";
    cout << "************************************************\n\n";
}

void banner3() {
    cout << "\n++++++++++++++++++++++++++++++++++++++++++++++++\n";
    cout << "             LET THE BATTLE BEGIN               \n";
    cout << "++++++++++++++++++++++++++++++++++++++++++++++++\n\n";
}


int main() {
    ifstream infile;
    string text, player1, player2, Dinosaur1, Dinosaur2;
    int lifePoint1, lifePoint2, hitPoint1, hitPoint2, diceRoll, DinoCho1, DinoCho2;
    char lineChar, answer1, enter4Roll, answer2;
    banner1();

    cout << "Player 1 Name: " << endl;
    cin >> player1;
    cout << "Player 2 Name: " << endl;
    cin >> player2;
    cout << "Do you wish to see the dinos before you pick one?" << endl;
    cin >> answer1;
    if (answer1 == 'y' || answer1 == 'Y') {
    infile.open("dinosaurFile.txt");
        if (!infile) {
            cout << "Cannot open file";
        }
        else if(infile.is_open())
        {
	        while(infile.good())
	        {
	     	   lineChar = infile.get();
	     	   cout << lineChar << "";
	        }
        }
	    infile.close();
        }
        cout << endl;
        cout << player1 << " CHOOSE YOUR DINO: " << endl;
        banner2();
        cout << player1 << " WHICH DINO WILL YOU USE (1-5): ";
        cin >> DinoCho1;

        switch(DinoCho1) {
            case 1:
            cout << player1 << " has selected Brachiosaurus\n"; 
            Dinosaur1 = "Brachiosaurus";
            break;
            case 2:
            cout << player1 << " has selected Pteradactyl\n";
            Dinosaur1 = "Pteradactyl";
            break;
            case 3:
            cout << player1 << "has selected T-Rex\n";
            Dinosaur1 = "T-Rex";
            break;
            case 4:
            cout << player1 << " has selected Triceratops\n";
            Dinosaur1 = "Triceratops";
            break;
            case 5:
            cout << player1 << " has selected Velociraptor\n";
            Dinosaur1 = "Velociraptor";
            break;
            default:
            cout << "I guess you don't want a dino, do you?\n";
            return 0;
        }
        if (DinoCho1 == 1) {
            lifePoint1 = 2000;
            hitPoint1 = 25;
        }
        else if (DinoCho1 == 2) {
            lifePoint1 = 800;
            hitPoint1 = 80;
        }
        else if (DinoCho1 == 3) {
            lifePoint1 = 1000;
            hitPoint1 = 60;
        }
        else if (DinoCho1 == 4) {
            lifePoint1 = 2000;
            hitPoint1 = 75;
        }
        else if (DinoCho1 == 5) {
            lifePoint1 = 800;
            hitPoint1 = 100;
        }

        cout << endl << player2 << " CHOOSE YOUR DINO: " << endl;
        banner2();
        cout << player2 << " WHICH DINO WILL YOU USE (1-5): ";
        cin >> DinoCho2;

        switch(DinoCho2) {
            case 1:
            cout << player2 << " has selected Brachiosaurus\n";
            Dinosaur2 = "Brachiosaurus";            
            break;
            case 2:
            cout << player2 << " has selected Pteradactyl\n";
            Dinosaur2 = "Pteradactyl";
            break;
            case 3:
            cout << player2 << "has selected T-Rex\n";
            Dinosaur2 = "T-Rex";            
            break;
            case 4:
            cout << player2 << " has selected Triceratops\n";
            Dinosaur2 = "Triceratops";
            break;
            case 5:
            cout << player2 << " has selected Velociraptor\n";
            Dinosaur2 = "Velociraptor";
            break;
            default:
            cout << "I guess you don't want a dino, do you?\n";
            return 0;
        }
        if (DinoCho2 == 1) {
            lifePoint2 = 2000;
            hitPoint2 = 25;
        }
        else if (DinoCho2 == 2) {
            lifePoint2 = 800;
            hitPoint2 = 80;
        }
        else if (DinoCho2 == 3) {
            lifePoint2 = 1000;
            hitPoint2 = 60;
        }
        else if (DinoCho2 == 4) {
            lifePoint2 = 2000;
            hitPoint2 = 75;
        }
        else if (DinoCho2 == 5) {
            lifePoint2 = 800;
            hitPoint2 = 100;
        }

        banner3();
        cout << Dinosaur1 << " vs. " << Dinosaur2 << endl;
        for (int i = 1; i < 3; i++) {
            cout << "Round " << i << endl;

            cout << player1 << " press any key to roll the dice\n";
            cin >> enter4Roll;
            diceRoll = 7;
            int hit1 = rand() % diceRoll ;
            cout << "Dice roll is: " << hit1 << endl;
            hitPoint1 = hit1 * hitPoint1;
            cout << "You hit " << player2 << "'s dinosaur for : " << hitPoint1 << " points.\n";
            lifePoint2 = lifePoint2 - hitPoint1;
            cout << Dinosaur2 << " has " << lifePoint2 << " life left.\n";
            if (lifePoint2 < 0) {
                cout << player1 << " wins!" << endl;
                break;
            }
            cout << player2 << " press any key to roll the dice\n";
            cin >> enter4Roll;
            diceRoll = 7;
            int hit2 = rand() % diceRoll;
            cout << "Dice roll is: " << hit2 << endl;;
            hitPoint2 = hit2 * hitPoint2;
            cout << "You hit " << player1 << "'s dinosaur for : " << hitPoint2 << " points.\n";
            lifePoint1 = lifePoint1 - hitPoint2;
            cout << Dinosaur1 << " has " << lifePoint1 << " life left.\n";
            if (lifePoint2 < 0) {
                cout << player2 << " wins!" << endl;
                break;
            }
        }
        
        cout << "Would you like to play again (y/n) ";
        cin >> answer2;
        
        if (answer2 == 'y' || answer2 == 'Y'){

        }
        else if (answer2 == 'n' || answer2 == 'N'){
            cout << "Goodbye!!";
            return 0;
        }
        else {
            cout << "You did not enter 'y' or 'n' ";
            cout << "Would you like to play again (y/n) ";
            cin >> answer2;
            if (answer2 == 'y' || answer2 == 'Y'){

            }
            else if (answer2 == 'n' || answer2 == 'N'){
                cout << "Goodbye!!";
                return 0;
            }
            else {
                cout << "THAT'S IT, I'M ENDING THIS!";
                return 0;
            }
            return 0;
    }
    return 0;
}
