/* --- LinkedList.h-----------------------------------------------------------------
    This program is the header file containing the LinkedList class. 
    You can put the entire class & function definitions in this one file if you want. 
    In fact, if you do the extra credit and make it in a Template class, 
    I highly recommend keeping it all in this one file.

    Written by:  Phillip Caruthers               Tennessee Technological University
    Written for: CSC 1310                        July 10, 2021
------------------------------------------------------------------------------*/

#ifndef LinkedList_H
#define LinkedList_H

using namespace std;

template <class LL> 
class LinkedList
{
    private:
        struct ListNode {
            string Dinosaur;
            ListNode *Next;
        };
        ListNode *head;
        ListNode *tail;
        int numNodes;
    public: 
        int length;
        int nodeValue;
        // Constructor
		LinkedList()
		{ 
			head = NULL; 
			tail = NULL;
			numNodes = NULL;
		}

		// Destructor (similar to a typical RemoveAll function)
		~LinkedList()
		{
			ListNode *tmpNode, *Next;
			while(*Next) {
				tmpNode = *Next;
				*Next = tmpNode->next;
				delete tmpNode;
			}
		}

		// only for the 1st Node
		void initNode(struct ListNode head, int n){
			head->data = n;
			head->next =NULL;
		}

		//To see how many dinos player has
		int getLength() const
		{
			return length;
		}
		
		//To see which dino is selected
		int getNodeValue() const
		{
			return nodeValue;
		}
		
		//Will add dino to head + 1
        LL appendNode(struct ListNode *head, int n)
		{
			ListNode *newNode = new ListNode;
			newNode->data = n;
			newNode->next = NULL;

			ListNode *cur = head;
			while(cur) {
				if(cur->next == NULL) {
					cur->next = newNode;
					return;
				}
				cur = cur->next;
			}
		}
		
		//Like append, except not
		LL insertNode(struct ListNode **head, int n) 
		{
			ListNode *newNode = new ListNode;
			newNode->data = n;
			newNode->next = *head;
			*head = newNode;
		}
		
		//Will delete a node
        bool deleteNode(struct ListNode **head, ListNode *ptrDel) {
			ListNode *cur = *head;
			if(ptrDel == *head) {
				*head = cur->next;
				delete ptrDel;
				return true;
			}

			while(cur) {
				if(cur->next == ptrDel) {
					cur->next = ptrDel->next;
					delete ptrDel;
					return true;
				}
				cur = cur->next;
			}
			return false;
		}
		LL addDino();
		LL lookDino();
		
		// Linked list operations
		bool isEmpty();
		void push(double);
		double pop()
		{
			if(!tail)
				return -1;
			else {
				remove;
			}
				
		}
		double peek()
		{
			if(!head)
				return -1;
			else
				return head->value;
		}
		void display(struct ListNode *head) {
			ListNode *list = head;
			while(list) {
				cout << list->data << " ";
				list = list->next;
			}
			cout << endl;
			cout << endl;
		}
};
#endif