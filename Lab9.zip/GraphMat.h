#ifndef GRAPHMAT_H
#define GRAPHMAT_H

#include <iostream>
using namespace std;

class GraphMat
{
private:
    bool **adjMatrix;
    int numVertices;
    int numEdges;

public:
    /* Constructor for Adjacency MAT
		- accepts the number of vertices in the graph, 
		- sets the private attribute numVertices, 
		- dynamically allocates matrix to adjMatrix
		- initialize the matrix to false
		*/
    GraphMat(int numV)
    {

    }

    /* Destructor 
		– deletes matrix 
		*/

    ~GraphMat()
    {

    }
    // Add Edge 
    void addEdgeMat(int v1, int v2)
    {

    }
    // print matrix
    void printAdjMat()
    {

    }
};

#endif