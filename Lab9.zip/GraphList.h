#ifndef GRAPHLIST_H
#define GRAPHLIST_H

#include <iostream>
using namespace std;

class GraphList
{
	private:
		struct ListNode
		{
			int value;
			struct ListNode* next;
		};
		ListNode** headArray;
		int numVertices;
		int numEdges;
		
	public:
		/* Constructor for Adjacency lists
		- accepts the number of vertices in the graph, 
		- sets the private attribute numVertices, 
		- dynamically allocates an array of pointers to ListNodes
		- initial all pointers are null.
		*/
		GraphList(int numV)
		{
			
		}


		/* Destructor 
		– deletes linked lists 
		*/

		~GraphList()
		{

		}
		
		// Add edge
		void addEdgeList(int v1, int v2)
		{

		}


		// Display Adjacency List
		void printAdjList()
		{

		}
};

#endif