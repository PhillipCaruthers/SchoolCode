/*
 *Title:    Assignment 3
 *Author:   Phillip Caruthers
 *Date:     6/11/21
 *Purpose:  Larry, what am I going to do with you?
*/
#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;

//Print banner function
void PrintBanner() {
    cout << "++++++++++++++++++++++++++++++++++++++" << endl;
    cout << "*Weyland-Yutani Basic Stat Calculator*" << endl;
    cout << "++++++++++++++++++++++++++++++++++++++" << endl;
}

//Print array function, this one is tricky for a user defined array.
void print_arr(int arr[], int arrSize) {
    for (int i = 0; i < arrSize; i++) {
        cout << arr[i];
    }
}

//Sort array function, I used the sort feature from the algortihm library.
void sort_arr(int arr[], int arrSize) {

    //int n = sizeof(arr) / sizeof(arr[0]);  sizeof messes with compiling the program for some reason.
    sort(arr, arr + arrSize);
    for (int i = 0; i < arrSize; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}

//Calculate average function, easy enough with a defined array.
int calc_avg(int arr[], int arrSize) {
    int total = 0;
    for (int i = 0; i < arrSize; i++) {
        total += i;
    }
    int average = total / arrSize;
    cout << "Average = " << average << endl;
    return 0;
}

//Calculate median function, much like average, again with a defined array.
int calc_median(int arr[], int arrSize) {

    int median = 0;

    if (arrSize % 2 != 0) {
        median = (double)arr[arrSize/2];
    }
    cout << "Median is: ";
    median = (int ( arr[ ( arrSize - 1 ) / 2 ] + arr[ arrSize / 2 ] ) / 2 );
    return 0;
}

//Calculate range function would be easier if I could include a max and a min library somehow.
int calc_range(int arr[], int arrSize) {
    int range = 0; 
    for (int i = 0; i < arrSize; i++) {
        sort(arr, arr + arrSize);
        range = arr[5] - arr[0]; 
    }
    return range;
}

//This one gave me the most trouble.
int calc_dot(int arr1[], int arr2[], int arrSize) {
    int i;
    for (i = 0; i < arrSize; i++) {
        cout << arr1[i];
        cout << arr2[i];
    }

    int total[i][i] = { arr1[i] * arr2[i] };
    
    cout << endl << "The product of the two matrix's is: " << endl;
    cout << total[i][i] << "  ";

    return 0;
}

int main()
{
	ifstream infile;
	string infileName;
	string text;
	int count = 0;
	string str1, str2, str3;
    int inArr[] = {count};
    int inArr2[] = {count};
    int arrSize = 10;

//Print banner first, and then get input file.    
    PrintBanner();

	cout << "Please enter an input file name: ";
	cin >> infileName;
    infile.open(infileName);
	
	if (infile.is_open()) {
		while(!infile.eof()) {
			while (infile >> text) {
			}
//Use functions after opening the input file, but after reading all the text from the file.
        print_arr(inArr, arrSize);
        sort_arr(inArr, arrSize);
        calc_avg(inArr, arrSize);
        calc_median(inArr, arrSize);
        calc_range(inArr, arrSize);
        calc_dot(inArr, inArr2, arrSize);
		}
	}
//If input file can't be opened, the program will automatically quit.
	else if (!infile.is_open())
	{
	cout << "Input file could not be opened." << endl;
	cout << "Quitting...";
	return 0;
	}

	infile.close();
	return 0;
}