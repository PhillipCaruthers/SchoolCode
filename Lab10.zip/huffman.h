// Program for Huffman Coding using Priority Queue
#ifndef HUFFMAN_H
#define HUFFMAN_H
#include <iostream>
#include <queue>
using namespace std;

// Maximum Height of Huffman Tree.
#define MAX_SIZE 100

class HuffmanTreeNode
{
public:
    char data; // Stores character
    int freq; // Stores frequency of the character

    // Left child of the current node
    HuffmanTreeNode *left;

    // Right child of the current node
    HuffmanTreeNode *right;

    // Constructor
    HuffmanTreeNode(char character, int frequency)
    {
        data = character;
        freq = frequency;
        left = right = NULL;
    }
};

// Custom comparator class
class Compare
{
public:
    bool operator()(HuffmanTreeNode *a, HuffmanTreeNode *b)
    {
        // Defining priority on the basis of frequency
        return a->freq > b->freq;
    }
};

// Function to generate Huffman Encoding Tree
HuffmanTreeNode *buildTree(priority_queue<HuffmanTreeNode *, vector<HuffmanTreeNode *>, Compare> pq)
{

    /*looping till only one node remains in the Priority Queue
    
        - set left node which has least frequency
        - remove node from Priority Queue

        - set right node which has least frequency
        - remove node from Priority Queue
       
        - formed a new node with frequency left->freq + right->freq
        - ake data as '$' because it only concerned with the frequency

        -Push back new node to the Priority Queue
    */
   return 0;
}

// display code of each character.
void displayCodes(HuffmanTreeNode *root, int arr[], int top)
{
    /* 
    - assign 0 to the left node and perform recursion
    - assign 1 to the right node and perform recursion
    - If this is a leaf node,then we print root->data
    */
    cout << "";
}

void HuffmanCodes(char data[],int freq[], int size)
{

    /* 
    - Declare priority queue using custom comparator
    - Populate the priority queue
    - Build Huffman Encoding Tree and get the root node
    - Display Huffman Codes
    */
    cout << ""; 
}

#endif

struct node
{
 node * leftChild;
 node * rightChild;
 double frequency;
    string content;
 string code;
};
vector<node> nodeArray;
node  extractMin()
{ 
 double temp = (double) INT_MAX;
    vector<node>::iterator i1,pos;
    for(i1 = nodeArray.begin();i1!=nodeArray.end();i1++)
 {
  
  if(temp>(*i1).frequency)
  {
     pos = i1;
     temp = (*i1).frequency;
  }
 }
 
 node tempNode = (*pos);
 nodeArray.erase(pos);
 
 
 
 return tempNode;
}
                     
node getHuffmanTree()
{
 
 
 while(!nodeArray.empty())
 {
      
  
   node * tempNode = new node;   
      node * tempNode1 = new node;
   node * tempNode2 = new node;
      *tempNode1 = extractMin();
   *tempNode2 = extractMin();
   
  
   tempNode->leftChild = tempNode1;
   tempNode->rightChild = tempNode2;
   tempNode->frequency = tempNode1->frequency+tempNode2->frequency;
   nodeArray.push_back(*tempNode);
   if(nodeArray.size() == 1)//only the root node exsits
   {
    break;
   }
 }
    return nodeArray[0];
}
void BFS(node * temproot,string s)
{
   node * root1 = new node;
   root1 = temproot;
  
   root1->code = s;
   if(root1 == NULL)
   {
    
   }
   else if(root1->leftChild == NULL && root1->rightChild == NULL)
   {
    
    cout<<"the content is "<<root1->content<<endl;
    cout<<"and its corresponding code is "<<root1->code<<endl;
   }
   else
   {
   
      root1->leftChild->code = s.append("0");
   s.erase(s.end()-1);
   root1->rightChild->code = s.append("1");
   s.erase(s.end()-1);
      BFS(root1->leftChild,s.append("0"));
   s.erase(s.end()-1);
      BFS(root1->rightChild,s.append("1"));
   s.erase(s.end()-1);
 }
   
}
void getHuffmanCode()
{
 int size,i;
 double tempDouble;
 string tempString = "";
 
 cout<<"please input the number of things you want to encode!"<<endl;
 cin>>size;
 
 for(i = 0;i<size;i++)
 {
  cout<<"please input the things you want to encoded and their frequencies!"<<endl;
  node tempNode;
  cin>>tempString;
  cin>>tempDouble;
  tempNode.frequency = tempDouble;
  tempNode.content = tempString;
  tempNode.leftChild = NULL;
  tempNode.rightChild = NULL;
  nodeArray.push_back(tempNode);
 }
 node root = getHuffmanTree();
 BFS(&root,"");
 
}