#ifndef BINARYTREE_H
#define BINARYTREE_H
#include <iostream>
using namespace std;

// Stack template

template <class T>
class BinaryTree
{
private:
   struct TreeNode
   {
      T value;           // The value in the node
      TreeNode *left;    // Pointer to left child node
      TreeNode *right;   // Pointer to right child node
   };

   TreeNode *root;       // Pointer to the root node
   
   // Private member functions
   //Added insert
   void insert(TreeNode *&, TreeNode *&);
   //the insert function should call the balance function 
   void destroySubTree(TreeNode *);
   void displayInOrder(TreeNode *) const;
   //Added display
   void display(TreeNode *ptr, int level);
   //this function will display a HORIZONTAL view of the tree’s cast member’s cast ID
   //and name’s first two alphabets (this must be a public function).  
   //modify the following functions to the binarytree class:

   
public:
   // Constructor
   BinaryTree()
      { root = NULL; }
      
   // Destructor
   ~BinaryTree()
      { destroySubTree(root); }
      
   // Binary tree operations
   void insertNode(T);
   void displayInOrder() const
      {  displayInOrder(root); } 
   void displayTree();
   TreeNode* balance(TreeNode *);
   //balance the tree into an avl tree
   //Added Height, Diff, rotations
   int height(TreeNode *);
   //find the height of a BST node and return it from this function
   int diff(TreeNode *);
   //find the height difference between the left & right subtrees of a given node and return it from this function 
   //Create a function for each possible rotation:
   TreeNode *r_rotation(TreeNode *); 
   //perform right rotation on a given parent node
   TreeNode *l_rotation(TreeNode *);
   //performs left rotation on a given parent node
   TreeNode *lr_rotation(TreeNode *);
   //performs left-right rotation on a given parent node
   TreeNode *rl_rotation(TreeNode *);
};

template <class T>
void BinaryTree<T>::displayTree()
{
   display(root, 1);
}
template <class T>
void BinaryTree<T>::display(TreeNode *ptr, int level)
{
   int i;
   if (ptr != NULL)
   {
      display(ptr->right, level + 1);

      cout << endl;
      if (ptr == root)
         cout << "ROOT-> ";
      for (i = 0; i < level && ptr != root; i++)
         cout << "       ";
      cout << (ptr->value);

      display(ptr->left, level + 1);
   }
}


//*************************************************************
// insert accepts a TreeNode pointer and a pointer to a node. *
// The function inserts the node into the tree pointed to by  *
// the TreeNode pointer. This function is called recursively. *
//*************************************************************
template <class T>
void BinaryTree<T>::insert(TreeNode *&nodePtr, TreeNode *&newNode)
{
   if (nodePtr == NULL)
      nodePtr = newNode; // Insert the node.
   else if (newNode->value < nodePtr->value)
   {
      insert(nodePtr->left, newNode); // Search the left branch
   }
   else
   {
      insert(nodePtr->right, newNode); // Search the right branch
   }
}

//**********************************************************
// insertNode creates a new node to hold num as its value, *
// and passes it to the insert function.                   *
//**********************************************************
template <class T>
void BinaryTree<T>::insertNode(T item)
{
   TreeNode *newNode = NULL; // Pointer to a new node.

   // Create a new node and store num in it.
   newNode = new TreeNode;
   newNode->value = item;
   newNode->left = newNode->right = NULL;

   // Insert the node.
   insert(root, newNode);
}

//***************************************************
// destroySubTree is called by the destructor. It   *
// deletes all nodes in the tree.                   *
//***************************************************
template <class T>
void BinaryTree<T>::destroySubTree(TreeNode *nodePtr)
{
   if (nodePtr)
   {
      if (nodePtr->left)
         destroySubTree(nodePtr->left);
      if (nodePtr->right)
         destroySubTree(nodePtr->right);
      delete nodePtr;
   }
}

//****************************************************************
// The displayInOrder member function displays the values        *
// in the subtree pointed to by nodePtr, via inorder traversal.  *
//****************************************************************
template <class T>
void BinaryTree<T>::displayInOrder(TreeNode *nodePtr) const
{
   if (nodePtr)
   {
      displayInOrder(nodePtr->left);
      cout << nodePtr->value << endl;
      displayInOrder(nodePtr->right);
   }
}
/*	height:  Find the height of a node and return it	*/

/*int TreeNode::height(TreeNode *temp) 
{
    int h = 0;
    if (temp != NULL)
    {
        int l_height = height(temp->getLeft());
        int r_height = height(temp->getRight());
        int max_height = max(l_height, r_height);
        h = max_height + 1;
    }
    return h;
}
/*	diff:  Find the HEIGHT DIFFERENCE between the left & right subtrees */

/*int TreeNode::diff(TreeNode *temp)
{
    int l_height = height(temp->getLeft());
    int r_height = height(temp->getRight());
    int b_factor= l_height - r_height;
    return b_factor;
}
*/
/*TreeNode *BinaryTree::l_rotation(TreeNode *parent)
{
    TreeNode *temp;
    temp = parent->getRight();
	
    parent->setRight(temp->getLeft()); //SWITCHING TEAMS (if node exists, NULL otherwise)
    temp->setLeft(parent);  //new parent node (move old parent to left)
	
    return temp;
}

/*	r_rotation:  Perform RIGHT ROTATION on this parent node	*/
/*TreeNode *BinaryTree::r_rotation(TreeNode *parent)
{
    TreeNode *temp;
    temp = parent->getLeft();
    parent->setLeft(temp->getRight()); //SWITCHING TEAMS
    temp->setRight(parent); //new parent node (move old parent to right)
    return temp;
}
 
/*	lr_rotation:  Perform LEFT-RIGHT ROTATION on this parent node	*/
/*TreeNode *BinaryTree::lr_rotation(TreeNode *parent)
{
    TreeNode *temp;
    temp = parent->getLeft();
    parent->setLeft(l_rotation(temp));
    return r_rotation(parent);
}
 
/*	rl_rotation:  Perform RIGHT-LEFT ROTATION on this parent node	*/
/*TreeNode *BinaryTree::rl_rotation(TreeNode *parent)
{
    TreeNode *temp;
    temp = parent->getRight();
    parent->setRight(r_rotation(temp));
    return l_rotation(parent);
}
 
/*	balance:	Balance the Tree into an AVL tree	*/
/*
BinaryTree *TreeNode::balance(TreeNode *temp)
{
    int bal_factor = diff (temp);
    if (bal_factor > 1)
    {
        if (diff(temp->getLeft()) > 0)  // 2, 1  RIGHT
		{
            temp = r_rotation(temp);
			cout << "\nRIGHT rotation";
		}
        else							// 2, -1 LEFT-RIGHT
		{
            temp = lr_rotation(temp);
			cout << "\nLEFT-RIGHT rotation";
		}
    }
    else if (bal_factor < -1)
    {
        if (diff (temp->getRight()) > 0) // -2, 1 RIGHT-LEFT
		{
            temp = rl_rotation(temp);
			cout << "\nRIGHT-LEFT rotation";
		}
        else 							// -2, -1 LEFT
		{
            temp = l_rotation(temp);
			cout << "\nLEFT Rotation";
		}
    }
    return temp;
}
 
/*	
	insert:	Insert a new node into the AVL tree with value	
			Uses recursive algorithm

*/
/*
BinaryTree *TreeNode::insert(TreeNode* root, int num) 
{
	//create a new TreeNode with given value
	TreeNode *newNode = new TreeNode;
	newNode->setValue(num);
	
	
	//figure out where this node should go!
	
	//should it be the root?
	if(root == NULL)
	{
		root = newNode;
		return root;
	}
	//otherwise, it is not the root...find the location
	TreeNode* cur = root;
	while (cur != NULL) 
	{
		if(newNode->getValue() < cur->getValue())	//move to the left subtree
		{
			if (cur->getLeft() == NULL)		//there is nothing on left of cur
			{
				cur->setLeft(newNode);		//so insert the new node here
				cur = NULL;				//this will allow us to exit the while loop (because we are done)
			}
			else						//there is something on left 
				cur = cur->getLeft();			//travel to left node & make it new cur
		}
		else							//move to the right subtree 
		{
			if (cur->getRight() == NULL) 	//there is nothing on the right of cur
			{
				cur->setRight(newNode);		//so insert the new node here
				cur = NULL;				//this will allow us to exit the while loop (because we are done)
			}
			else
				cur = cur->getRight();
		}
	}

	//now the new node is already inserted so 
	//the next step is to make sure tree is balanced
	root = balance(root);
	
	return root;
}

 
/*	
	display:  	Display the AVL Tree	
				Uses recursive algorithm
*/
/*
void TreeNode::display(TreeNode *ptr, int level)
{
    int i;
    if (ptr!=NULL)
    {
        display(ptr->getRight(), level + 1);
        printf("\n");
        for (i = 0; i < level && ptr != root; i++)
            cout<<"        ";
        cout<<ptr->getValue();
        display(ptr->getLeft(), level + 1);
    }
}
 
/*	inorder:  print the tree node values using in-order traversal 	*/
/*
void BinaryTree::inorder(TreeNode *tree)
{
    if (tree == NULL)
        return;
    inorder (tree->getLeft());
    cout<<tree->getValue()<<"  ";
    inorder (tree->getRight());
}
*/
/*	preorder:  print the tree node values using pre-order traversal 	*/
/*
void BinaryTree::preorder(TreeNode *tree)
{
    if (tree == NULL)
        return;
    cout<<tree->getValue()<<"  ";
    preorder (tree->getLeft());
    preorder (tree->getRight());
 
}
*/
/*	postorder:  print the tree node values using post-order traversal 	*/
/*
void BinaryTree::postorder(TreeNode *tree)
{
    if (tree == NULL)
        return;
    postorder ( tree->getLeft() );
    postorder ( tree->getRight());
    cout<<tree->getValue()<<"  ";
}
*/
#endif