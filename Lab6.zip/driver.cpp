
#include <iostream>
#include "BST.h"
#include <fstream>
using namespace std;

int main()
{
	int num = 0;
	BST<int> tree; 

	// put data into object
	//Graph1
	tree.insert(33);
	tree.insert(40);
	tree.insert(10);
	tree.insert(65);
	tree.insert(58);
	tree.insert(22);

	//Graph2
	tree.insert(10);
	tree.insert(23);
	tree.insert(33);
	tree.insert(40);
	tree.insert(58);
	tree.insert(65);
	tree.insert(79);

	//Graph3
	tree.remove(79);

	//Graph4
	tree.remove(40);
	
	//Graph5
	tree.remove(33);


	/*------------------------------------------------------------------------
    Above insertions are for step1.
    Initially, run this program to get output file graph_1.txt.
    So, for each other steps add instructions below it and, 
    change graph_1.txt to graph_(step number).txt (for example: for step2, graph_2.txt) and run.

   -----------------------------------------------------------------------*/
	

	ofstream fileout;
	fileout.open("graph_4.txt", std::ofstream::out | std::ofstream::trunc);
	tree.graph(fileout);
	return 0;
}