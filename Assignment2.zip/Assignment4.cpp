/*
 *Title:    Last Assignment
 *Author:   Phillip Caruthers
 *Date:     6/18/21
 *Purpose:  Has Larry turned his life around?
*/

#include <iostream>
#include <fstream>
#include <string>
#include "records.h"
using namespace std;

int main()
{
    show_banner();

    ifstream infile;
	string infileName;
	string text;
	string song, record, label;
    const int arrSong = 5;
    int arr[arrSong];
    int option = 0;
    int count = 0;
    cout << "Please select from the following options: \n";
    cout << "1)        Read Records" << endl;
    cout << "2)        Show Records" << endl;
    cout << "3)        Quit" << endl;
    cin >> option;

    //I have switch and break options for all three options, plus one if a user inputs an invalid option
    switch (option) {
        case 1:
        cout << "Menu 1) Read Records" << endl;
        cout << "Please enter an input file name: ";
        cin >> infileName;
        infile.open(infileName);
	
	    if (infile.is_open()) {
			for (int i = 0; i < 2; i++) {
                read_records(song);
                create_record(song, record, label, arrSong);
                create_song(song, arrSong);
                //add_song();
		    }
		}

    //If input file can't be opened, the program will automatically quit.
        else if (!infile.is_open())
        {
        cout << "Input file could not be opened." << endl;
        cout << "Quitting...";
        return 0;
        }

        infile.close();
        break;
        
        case 2:
        cout << "Menu 2) Show Records" << endl;
        if (infile.is_open()) {
            while (!infile.eof()) {
                getline(infile, text);
                cout << text;
                count++;
            }
        }
        infile.close();
       //show_records(Records*);
       //show_record(Record);
       //show_song(Song);
        break;
        
        case 3:
        song = "";
        record = "";
        //delete_records(Records*)
        break;

        default:
        cout << "Invalid option";
        return 0;
    }
    return 0;
}