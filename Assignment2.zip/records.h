/*
 *Title:    Last Assignment
 *Author:   Phillip Caruthers
 *Date:     6/18/21
 *Purpose:  Has Larry turned his life around?
*/

#include <iostream>
#include <fstream>
#include <string>

using namespace std;
struct Song {
    int SongLength;
    string SongTitle;
};

struct Record {
    string RecordTitle, RecordArtist, RecordLabel;
    Song arrSong, SongSize, CurrArrSong;
};

struct Records {
    Record arrRecord, RecordSize, CurrArrRecord;
};
void show_banner();
Records* read_records(string);
Record create_record(string, string, string, int);
Song create_song(string, float);
void add_song(Record*, Song);
void show_records(Records*);
void show_record(Record);
void show_song(Song);
void delete_records(Records*);
