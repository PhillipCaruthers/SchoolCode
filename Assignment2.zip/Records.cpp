/*
 *Title:    Last Assignment
 *Author:   Phillip Caruthers
 *Date:     6/18/21
 *Purpose:  Has Larry turned his life around?
*/

#include <iostream>
#include <fstream>
#include <string>
#include "records.h"

using namespace std;

void show_banner() {
    cout << "++++++++++++++++++++++++++++++++++++++++++\n";
    cout << "*Welcome to the Colossal Record Database!*\n";
    cout << "++++++++++++++++++++++++++++++++++++++++++\n";
}
Records* read_records(string) {
    new Records*;
    Record arr1[] = {};
    cout << endl;
    return 0;
}
Record create_record(string, string, string, int) {
    Record recordVar;
//  recordVar += string + string + string + int;  
    cout << endl;
    return recordVar;
}
Song create_song(string, float) {
    Song songVar;
//    songVar += string + float;
    return songVar;
}
void add_song(Record*, Song) {
//    cin >> SongTitle;
    cout << endl;
}
void show_records(Records*) {
    cout << endl;
}
void show_record(Record) {
    cout << endl;
}
void show_song(Song) {
    cout << endl;
}
void delete_records(Records*) {
    cout << endl;
}
