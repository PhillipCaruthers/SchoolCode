#include <iostream>
#include <sstream>
#include <stack>
using namespace std;

#include "Stack.h"

float scanNum(char ch){
   int value;
   value = ch;
   return float(value-'0');
}

int isOperator(char ch){
   if(ch == '+'|| ch == '-'|| ch == '*'|| ch == '/')
      return 1;
   return -1;
}

int isOperand(char ch){
   if(ch >= '0' && ch <= '9')
      return 1;
   return -1;
}

float operation(int a, int b, char op){
   if(op == '+')
      return b+a;
   else if(op == '-')
      return b-a;
   else if(op == '*')
      return b*a;
   else if(op == '/')
      return b/a;
   else
      return op;
}

float postfixEval(string postfix){
   int a, b;
   stack<float> stk;
   string::iterator i;
   for(i=postfix.begin(); i!=postfix.end(); i++){
      if(isOperator(*i) != -1){
         a = stk.top();
         stk.pop();
         b = stk.top();
         stk.pop();
         stk.push(operation(a, b, *i));
      }
      else if(isOperand(*i) > 0){
         stk.push(scanNum(*i));
      }
   }
   return stk.top();
}

int main() 
{
   Stack myStack;
   StackElement num1;
   string line;
   string token;

   int a, b;
   char op;
   cout << "Please enter an equation to answer: ";
   getline(cin, line);

   // Create a string stream that will read from "line"
   stringstream ss(line,stringstream::in);
  
   // While there are more tokens...
   string post = " ";
   cout << "The result is: "<<postfixEval(post) << endl;

      //
      // if the token is an integer (not a +, -, *, or /)
      //   it is pushed onto a stack 
      // else if the token is an operator (it is a +, -, *, or /)
      //   two items are popped off the stack
      //   the operator is applied to them
      //   the result is pushed back onto the stack
      //

      // Put your code for evaluating the expression here!

   int finalanswer=myStack.top();
   cout << "The answer is " << finalanswer << endl;
   // There should be one and only one item left on the stack
   // print the item at the top of the stack

   return 0;
}
