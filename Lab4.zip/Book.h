/////////////////////////////
// Book class
/////////////////////////////
#ifndef BOOK_H
#define BOOK_H

#include <iostream>
#include <string>
using namespace std;

class Book
{

	private:
		string title;
		string authors;
		int num_pages;		

	public:
		Book() 
		{
		}
	
		Book(string t, string a, int num ) 
		{
			title = t;
			authors = a;
			num_pages = num;
		}

		//***********************ACCESSOR FUNCTIONS***************************
		string getTitle() const
		{
			return title;
		}
		string getAuthors() const
		{
			return authors;
		}
		int getNumPages() const
		{
			return num_pages;
		}
		
		//***********************MUTATOR FUNCTIONS***************************
		void setTitle(string t)
		{
			title = t;
		}
		void setAuthors(string a)
		{
			authors = a;
		}
		void setNumPages(int num)
		{
			num_pages = num;
		}
		
		//***********************OVERLOADED OPERATORS***************************
		
		friend ostream &operator << (ostream &strm, Book &s)
		{
			strm << "Book Title: " << s.title << "\nAuthors: " << s.authors << "\nNumber of pages: " << s.num_pages << endl << endl;
			return strm;
		}
};

#endif