#include "Book.h"
#include "Timer.h"
#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;

void selectionSort(Book *myBookArray, int numBooks);
void bubbleSort(Book *myBookArray[], int numBooks);
void reverseQuickSort(Book *myBookArray, int low, int high);
int partition(Book *myBookArray, int left, int right);
void swap(int *xp, int *yp);

int main()
{
	Book *myBookArray;
	myBookArray = new Book[150000];
	int numBooks = 0;
	int num_pages;
	string temp;

	ofstream outFile;
	ifstream inFile;

	time_t start, end;
	char filename[50];
	cout << "\n\nWhat is the name of the file with Books? (example.txt)\n\n";
	cin >> filename;
	inFile.open(filename);

	if (!inFile)
	{
		cout << "\n\nSorry, I can't open the file Books.txt\n\n";
		exit(1);
	}

	while (getline(inFile, temp) && numBooks != 150000)
	{
		myBookArray[numBooks].setTitle(temp);
		getline(inFile, temp);
		myBookArray[numBooks].setAuthors(temp);
		getline(inFile, temp);
		num_pages = stoi(temp);
		myBookArray[numBooks].setNumPages(num_pages);
		numBooks++;
		cout <<numBooks<<endl;
	}
	cout << "\n\nYou have created " << numBooks << " Book objects.\n\n";

	//sort the Books using selection sort and print them out to the text file numBooks_selectionSort.txt
	start = getTime(); //Starts timer.
	//selectionSort(myBookArray, numBooks);
	end = getTime(); //Ends timer.
	outFile.open(to_string(numBooks) + "_selectionSort.txt");
	cout << "\nSelection sort: " << totalTime(start, end) << " seconds\n\n";
	for (int x = 0; x < numBooks; x++)
	{
		outFile << myBookArray[x];
	}
	outFile.close();


	//sort the Books using reverse quick sort and print them out to the text file numBooks__reverseQuickSort.txt
	start = getTime(); //Starts timer.
	//reverseQuickSort(myBookArray, 0, numBooks - 1);
	end = getTime(); //Ends timer.
	cout << "\nReverse quick sort: " << totalTime(start, end) << " seconds\n\n";
	outFile.open(to_string(numBooks) + "_reverseQuickSort.txt");
	for (int x = 0; x < numBooks; x++)
	{
		outFile << myBookArray[x];
	}
	outFile.close();

	//sort the Books in reverse order using bubble sort & print them out to the text file numBooks_bubbleSort.txt
	start = getTime(); //Starts timer.
	//bubbleSort(myBookArray, numBooks);
	end = getTime(); //Ends timer.
	outFile.open(to_string(numBooks) + "_bubbleSort.txt");
	cout << "\nBubble sort: " << totalTime(start, end) << " seconds\n\n";
	for (int x = 0; x < numBooks; x++)
	{
		outFile << myBookArray[x];
	}
	outFile.close();

	delete[] myBookArray;
	return 0;
}

void swap(int *xp, int *yp)
{
    int temp = *xp;
    *xp = *yp;
    *yp = temp;
}

void selectionSort(Book *myBookArray[], int numBooks)
{
    /*for (int i = 0; i < numBooks - 1; ++i) {

   		int indexSmallest = i;
   		for (int j = i + 1; j < numBooks; ++j) {
		    
   		   if (myBookArray[j] < myBookArray[indexSmallest]) {
   		      indexSmallest = j;
   		   }
   		}
		int temp = myBookArray[i];
   		myBookArray[i] = myBookArray[indexSmallest];
   		myBookArray[indexSmallest] = temp;
	}*/
	int i, j;
   bool swapped;
   for (i = 0; i < numBooks - 1; i++)
   {
     swapped = false;
     for (j = 0; j < numBooks - i - 1; j++)
     {
        if (myBookArray[j] > myBookArray[j+1])
        {
           swap(myBookArray[j], myBookArray[j+1]);
           swapped = true;
        }
     }
  
     // IF no two elements were swapped by inner loop, then break
     if (swapped == false)
        break;
   }
   cout << myBookArray << endl;
	cout << myBookArray << endl;
}

void reverseQuickSort(Book *myBookArray[], int low, int high)
{
   /*int midpoint = low + (high - low) / 2;
   int pivot = myBookArray[midpoint];
 
   bool done = false;
   while (!done) {
      while (myBookArray[low] < pivot) {
         low += 1;
      }
      while (pivot < myBookArray[high]) {
         high -= 1;
      }
      if (low >= high) {
         done = true;
      }
      else {
         int temp = myBookArray[low];
         myBookArray[low] = myBookArray[high];
         myBookArray[high] = temp;
         low += 1;
         high -= 1;
      }
   }*/
   int i, j;
   bool swapped;
   for (i = 0; i < low - 1; i++)
   {
     swapped = false;
     for (j = 0; j < low - i - 1; j++)
     {
        if (myBookArray[j] > myBookArray[j+1])
        {
           swap(myBookArray[j], myBookArray[j+1]);
           swapped = true;
        }
     }
  
     // IF no two elements were swapped by inner loop, then break
     if (swapped == false)
        break;
   }
   cout << myBookArray << endl;
	cout << myBookArray << endl;
}

//mid partition algorithm
int partition(Book *myBookArray, int left, int right)
{
	//WRITE YOUR MID PARTITION CODE HERE
	return 0;
}

void bubbleSort(Book *myBookArray[], int numBooks)
{
   int i, j;
   bool swapped;
   for (i = 0; i < numBooks - 1; i++)
   {
     swapped = false;
     for (j = 0; j < numBooks - i - 1; j++)
     {
        if (myBookArray[j] > myBookArray[j+1])
        {
           swap(myBookArray[j], myBookArray[j+1]);
           swapped = true;
        }
     }
  
     // IF no two elements were swapped by inner loop, then break
     if (swapped == false)
        break;
   }
   cout << myBookArray << endl;
}
