#include <iostream>
using namespace std;

int sumOfPosInt(int);
int fiboNum(int);
int fact(int);

int main(int argc, char *argv[])
{
	int num = atoi(argv[1]);

	cout << "Enter an integer greater than 0: " << endl;
	cin >> num;
	
	cout << "\n #SUM OF Positive Integers \n";
	cout << " The sum is:  " << sumOfPosInt(num)<<endl;
	cout << "\n #Fibonacci Number \n";
	cout << " The number is:  " << fiboNum(num) << endl;
	cout << "\n #Factorial Calculation \n";
	cout << " " << num << "! is equal to " << fact(num) << endl;
	cout << "\n***** end *****\n";
	return 0;
}

int sumOfPosInt(int num) {
	if (num < 0) {
		return 0;
	}
	else {
		return sumOfPosInt(num - 1) + num;
	}
}

int fiboNum(int num) {
	if (num == 0) {
		return 0;
	}
	else if (num == 1) {
		return 1;
	}
	else {
		return fiboNum(num - 1) + fiboNum(num - 2);
	}
}

int fact(int num) {
	if (num == 0) {
		return 1;
	}
	else if (num == 1) {
		return 1;
	}
	else if (num < 0) {
		return 0;
	}
	else {
		return fact(num - 1) * num;
	}
}