#ifndef HEAP
#define HEAP

#include "Student.h"
#include <cmath> // for log2 & ceil
#include <iostream>
using namespace std;

template <typename ItemType>
class Heap
{
private:
	ItemType *items; // Array of heap items
	int heap_size;	 // Current count of heap items
	int capacity;	 // Maximum capacity of the heap

	int parent(int i) //get the parent of index i
	{
		// Write your code here!
		return (i-1)/2; 
	}
	int left(int i) //get the left child of index i
	{
		
		// Write your code here!
		return (2*i + 1); 
	}
	int right(int i) //get the right child of index i
	{
		// Write your code here!
		return (2*i + 2); 
	}
	
	void swap(ItemType *x, ItemType *y)
	{
		// Swap values
		// Write your code here!
		ItemType temp = *x;
		*x = *y;
		*y = temp;
	}

	bool isLeaf(int nodeIndex) // Tests whether this node is a leaf.
	{
		return (left(nodeIndex) >= heap_size);
	}


	// Converts a semiheap to a heap.
	void heapRebuild(int subTreeRootIndex);


public:
	Heap(int);
	~Heap();

	bool isEmpty() const; // Checks to see if the heap is empty

	int getNumberOfNodes() const; // Gets the number of nodes in this heap.

	int getHeight() const; // Gets the height of this heap.

	void resizeArray();

	void insert(ItemType newData); //Insert newData in the heap

	ItemType remove(); //Remove the root (maximum value) & returns it
};

//******************************************************************
//
// Private functions start here
//
//******************************************************************

template <typename ItemType>
void Heap<ItemType>::heapRebuild(const int subTreeNodeIndex)
{
	if (!isLeaf(subTreeNodeIndex))
	{
		/* 
		-Find larger child
			- A left child must exist
	    	- Make assumption about larger child
			- A right child might not exist

		- Check to see whether a right child exists
			- A right child exists; check whether it is larger
	       - If right then the initial assumption was wrong
		
		-If root value is smaller that the value in the larger child, 
			- Swap values
			- Continue with the recursion at that child
		*/

		// Write your code here!
		int leftChildIndex = left(subTreeNodeIndex);   
		int largerChildIndex = leftChildIndex;         	
		int rightChildIndex = right(subTreeNodeIndex); 	
		if (rightChildIndex < heap_size)
		{
			if (items[rightChildIndex] > items[largerChildIndex])
				largerChildIndex = rightChildIndex;		
		} 
		if (items[subTreeNodeIndex] < items[largerChildIndex])
		{
			swap(&items[largerChildIndex], &items[subTreeNodeIndex]);
			heapRebuild(largerChildIndex);
		}  
	}

}


//******************************************************************
//
// Public functions start here
//
//******************************************************************

template <typename ItemType>
Heap<ItemType>::Heap(int num)
{
	heap_size = 0;
	capacity = num;
	items = new ItemType[capacity];
}

template <typename ItemType>
Heap<ItemType>::~Heap()
{
	delete[] items;
}

template <typename ItemType>
bool Heap<ItemType>::isEmpty() const
{
	if (heap_size == 0)
		return true;
	else
		return false;
}

template <typename ItemType>
int Heap<ItemType>::getHeight() const
{
	return ceil(log2(heap_size + 1));
}

template <typename ItemType>
int Heap<ItemType>::getNumberOfNodes() const
{
	return heap_size;
}

template<typename ItemType>
void Heap<ItemType>::resizeArray()	//make an array 2 times as big as original
{
	int cap = capacity * 2; 
	ItemType *newHeapArray = new ItemType[cap];
	
	for(int x = 0; x < capacity; x++)
	{
		newHeapArray[x] = items[x];
	}
	delete [] items;
	items = newHeapArray;
	capacity = cap;
}

template <typename ItemType>
void Heap<ItemType>::insert(ItemType newData)
{
	/* 
	- First insert the new value at the end
    - Fix the max heap property if it is violated
	*/
	// Write your code here!
	if (heap_size == capacity)
	{
		resizeArray();
	}
	items[heap_size] = newData;
	heap_size++;
	int i = heap_size-1;
	while ((i != 0) && (items[parent(i)] < items[i]))
	{
		swap(&items[i], &items[parent(i)]);
		i = parent(i);
	} 
}


template <typename ItemType>
ItemType Heap<ItemType>::remove()
{
	ItemType temp;
	if (!isEmpty())
	{
		/* 
		- Store the root value so it can be returned later
		- Set the root node (first element) to the last element (step 2 in remove process)
		- Decrement the heap's size
		- adjust heap-shift elements down as needed(step 3 in remove process)
		*/

		// Write your code here!
		temp = items[0];						
		items[0] = items[heap_size - 1];		
		heap_size--;							
		heapRebuild(0);							
	}
	else
	{
		cout << "\nThe heap is empty so I can't remove any values.\n";
	}

	return temp;
}

#endif
