#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <string>
#include "Assignment3.h"

using namespace std;

int main() {
    char answer;
    string userAnimal;
    string ansAnimal;

    cout << "Welcome to 20 questions, the animal version.\n\n";
    
	BinaryTreeNode<string> *taxonomy_root_ptr;
	instruct();
	//set the beginning tree
	taxonomy_root_ptr = beginning_tree();
	do
	{
		//play the game
		play(taxonomy_root_ptr);
	    //taxonomy_root_ptr = beginning_tree();
		//set the beginning tree
	}
	//as long as user does not enter no play agian
	while (inquire("Shall we play again?"));
	cout << "Thank you for teaching me a thing or two." << endl;

	return EXIT_SUCCESS;
    return 0;
}
