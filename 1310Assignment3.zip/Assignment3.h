#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string>
using namespace std;

void eat_line();
bool inquire(const char query[]);

template <class Item>
struct BinaryTreeNode
{
	Item data;
	BinaryTreeNode *left;
	BinaryTreeNode *right;

};

template <class Item>
BinaryTreeNode<Item>* create_node
(
 const Item& entry,
 BinaryTreeNode<Item>* l_ptr,
 BinaryTreeNode<Item>* r_ptr
 );

template <class Item>
bool is_leaf(const BinaryTreeNode<Item>& node);

template <class Item>
void tree_clear(BinaryTreeNode<Item>*& root_ptr);

template <class Item>
BinaryTreeNode<Item>* tree_copy(BinaryTreeNode<Item>* root_ptr);

void instruct();
//the starting questions and answers
BinaryTreeNode<string>* beginning_tree();
//fills in users input and saves it
void learn(BinaryTreeNode<string>*& leaf_ptr);
//moves pointer to next question if the question is answered with a no
void ask_and_move(BinaryTreeNode<string>*& current_ptr);
//asks user to think of a question
void play(BinaryTreeNode<string>* current_ptr);

//the game instructions
void instruct() 
{
	cout << "Instructions: " << endl;
	cout << "Think of an animal." << endl;
	cout << "I will then try to guess your animal." << endl;
	cout << "    -If the program cannot guess your animal it will ask you" << endl;
	cout << "     to enter the correct answer followed by a question to"<< endl;
	cout << "     tell apart the last guessed animal and your animal." << endl;
	cout << "After I guess your animal correctly or incorrecly, you can either play again or exit." << endl << endl;
}

BinaryTreeNode<string>* beginning_tree()
{
	BinaryTreeNode<string> *root_ptr;
	BinaryTreeNode<string> *child_ptr;

	const string root_question("Are you a mammal?");
	const string left_question("Are you bigger than a cat?");
	const string right_question("Do you live underwater?");
	const string animal1("Kangaroo");
	const string animal2("Mouse");
	const string animal3("Trout");
	const string animal4("Robin");
	//position root_ptr at the root question
	root_ptr = create_node(root_question);
	//make the left question
	child_ptr = left_question;
	//make left answer
	child_ptr->left = animal1;
	//make right answer
	child_ptr->right = animal2;
	root_ptr->left = child_ptr;
	//make the right question
	child_ptr = right_question;
	//make left answer
	child_ptr->left = animal3;
	//make right answer
	child_ptr->right = animal4;
	root_ptr->right = child_ptr;
	
	return root_ptr;
}
//inserts answer and question into the tree
void learn(BinaryTreeNode<string>*& leaf_ptr) {
	string guess_animal;
	string correct_animal;
	string new_question;

	guess_animal = leaf_ptr->data;
	cout << "I give up. What are you? " << endl;
	getline(cin, correct_animal);

	//save the correct animal to a file
	ofstream animal_file;
	animal_file.open("Animals.txt", ios::app);
	if(!animal_file.is_open())
		cout << "Error opening animal file!";
	else if (animal_file.is_open())
		animal_file << correct_animal << endl;
	animal_file.close();

	cout << "Please type a yes/no question that will distinguish a" << endl;
	cout << correct_animal << " from a " << guess_animal << "." << endl;
	getline(cin, new_question);

	//save the new question to a file
	ofstream question_file;
	question_file.open("Questions.txt", ios::app);
	if(!question_file.is_open())
		cout << "Error opening question file!";
	else if (question_file.is_open())
		question_file << new_question << endl;
	question_file.close();
	leaf_ptr->data = new_question;
	cout << "As a " << correct_animal << ", " << new_question << endl;
	//if yes then set the correct animal to be the right side answer
	if (inquire("Please answer"))
	{
		leaf_ptr->left = correct_animal;
		leaf_ptr->right = guess_animal;
	}
	//other wise make it the left side answer
	else 
	{
		leaf_ptr->left = guess_animal;
		leaf_ptr->right = correct_animal;
	}

}
//reposition the pointer
void ask_and_move(BinaryTreeNode<string>*& current_ptr)
{
	cout << current_ptr->data;
	//if answer is yes then position pointer left
	if (inquire(" Please answer"))
		current_ptr = current_ptr->left;
	//otherwise move it to the right
	else 
		current_ptr = current_ptr->right;
}

void play(BinaryTreeNode<string>* current_ptr)
{
	cout << "Think of an animal, then press enter.";
	//hit enter key
	eat_line();
	//if the current pointer is not empty then move the current pointer
	while (!is_leaf(*current_ptr))
		ask_and_move(current_ptr);

	cout << ("My guess is " + current_ptr->data);
	if (!inquire(". Am i right?"))
	//if answers no then put the answer and question into the tree
		learn(current_ptr);
	else
		cout << "I knew it all along!" << endl;
}        